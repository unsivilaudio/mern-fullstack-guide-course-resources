import React from 'react';

const Users = () => {
  return <h2>Users Works!</h2>;
};

export default Users;
